$(document).ready(function () {
	window.location.href = "https://shuttl.typeform.com/to/EbEUgB";
});
